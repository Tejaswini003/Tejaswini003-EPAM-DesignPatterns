package Creational.FactoryMethodPattern;

public class PremiumPlan extends Plan {

	@Override
	void getRate() {
		// TODO Auto-generated method stub
		rate = 7.5;
	}

}
