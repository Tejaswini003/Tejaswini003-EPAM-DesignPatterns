package structural.facadeDesignPattern;

public class Rectange implements Shape {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("This is rectange");
	}

}
