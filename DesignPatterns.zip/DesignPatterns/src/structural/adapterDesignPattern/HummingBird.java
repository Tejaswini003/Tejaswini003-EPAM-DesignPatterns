package structural.adapterDesignPattern;

public class HummingBird implements Bird {

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("Flying...................");
	}

	@Override
	public void makeSound() {
		// TODO Auto-generated method stub
		System.out.println("chirp.....chirp.....");
	}

}
