package structural.adapterDesignPattern;

public class PlasticToyDuck implements ToyDuck {

	@Override
	public void squeak() {
		// TODO Auto-generated method stub
		System.out.println("squeak.........");
	}

}
