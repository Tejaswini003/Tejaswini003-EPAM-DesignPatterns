package behavioral.strategyDesignPattern;

public interface Payment {
public void pay(double amount);
}
