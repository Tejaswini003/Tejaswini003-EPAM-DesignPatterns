package behavioral.iteratorDesignPattern;

public interface Container {
	public Iterator getInterator();
}
